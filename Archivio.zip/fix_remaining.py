#!/usr/bin/env python3
"""Fix persistent_memory.py (re.DOTALL) e benchmark.py (f-string)."""
import re
from pathlib import Path

# Fix 1: persistent_memory.py - sostituisci tutti i "re." rimasti con "_re."
mem_file = Path("CORE/persistent_memory.py")
content = mem_file.read_text()
# Sostituisci "re.DOTALL" e qualsiasi "re." rimasto con "_re."
content = re.sub(r'\bre\.', '_re.', content)
mem_file.write_text(content)
import ast
ast.parse(content)
print("OK: persistent_memory.py fixato (re.DOTALL -> _re.DOTALL)")

# Fix 2: benchmark.py - riscrivi la funzione format_results senza f-string con \n
bench_file = Path("CORE/benchmark.py")
content = bench_file.read_text()

# Sostituisci la riga problematica
old_line = 'lines.append(f"\\n{model}:")'
new_line = 'lines.append(chr(10) + model + ":")'
content = content.replace(old_line, new_line)

# Sostituisci anche il return finale
old_return = 'return "\\n".join(lines)'
new_return = 'return chr(10).join(lines)'
content = content.replace(old_return, new_return)

bench_file.write_text(content)
ast.parse(content)
print("OK: benchmark.py fixato (f-string -> chr(10))")
