#!/usr/bin/env python3
"""fix_timestral_advice_file.py — Timestral scrive l'advice su file per la GUI."""
import re
import shutil
from pathlib import Path

THERM_FILE = Path("MONITORING/thermal_manager.py")
BACKUP = Path("MONITORING/thermal_manager.py.bak.advice")


def main():
    if not THERM_FILE.exists():
        print(f"❌ {THERM_FILE} non trovato")
        return 1
    
    content = THERM_FILE.read_text()
    
    if "timestral_advice.json" in content:
        print("ℹ  Fix già applicato, skip")
        return 0
    
    shutil.copy2(THERM_FILE, BACKUP)
    
    # Trova il metodo _sample_loop e aggiungi la scrittura del file advice
    # dopo l'aggiornamento di last_sample
    old = '''                sample = self._take_sample()
                if sample:
                    self.last_sample = sample
                    self.history.append(sample)
                    # Salva storico su disco ogni 10 campioni (~5 min)
                    if len(self.history) % 10 == 0:
                        self._save_history()
                    self.log.debug(
                        f"[timestral] sample: temp={sample.cpu_temp_max:.1f}C "
                        f"load={sample.cpu_load*100:.0f}% "
                        f"freq={sample.cpu_freq_avg//1000}MHz "
                        f"mem={sample.mem_used_ratio*100:.0f}%"
                    )'''
    
    new = '''                sample = self._take_sample()
                if sample:
                    self.last_sample = sample
                    self.history.append(sample)
                    # Salva storico su disco ogni 10 campioni (~5 min)
                    if len(self.history) % 10 == 0:
                        self._save_history()
                    self.log.debug(
                        f"[timestral] sample: temp={sample.cpu_temp_max:.1f}C "
                        f"load={sample.cpu_load*100:.0f}% "
                        f"freq={sample.cpu_freq_avg//1000}MHz "
                        f"mem={sample.mem_used_ratio*100:.0f}%"
                    )
                    # 🆕 Scrivi advice su file per la GUI (LLM tuner indicator)
                    try:
                        advice = self.get_advice()
                        import json as _json
                        advice_file = Path("state/timestral_advice.json")
                        advice_file.parent.mkdir(parents=True, exist_ok=True)
                        advice_data = {
                            "action": advice.action,
                            "tick_multiplier": advice.tick_multiplier,
                            "reason": advice.reason,
                            "timestamp": sample.timestamp,
                            "cpu_temp": sample.cpu_temp_max,
                            "gpu_temp": getattr(sample, "gpu_temp", 0.0),
                            "cpu_load": sample.cpu_load,
                        }
                        advice_file.write_text(_json.dumps(advice_data, indent=2))
                    except Exception as e:
                        self.log.debug(f"advice file write failed: {e}")'''
    
    if old in content:
        content = content.replace(old, new, 1)
        THERM_FILE.write_text(content)
        
        try:
            compile(content, "thermal_manager.py", "exec")
            print("✓ Timestral ora scrive advice su state/timestral_advice.json")
            print("  La GUI mostrerà lo stato reale del LLM tuner")
        except SyntaxError as e:
            print(f"❌ Errore sintassi: {e}")
            shutil.copy2(BACKUP, THERM_FILE)
            return 1
    else:
        print("❌ Pattern _sample_loop non trovato")
        return 1
    
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
