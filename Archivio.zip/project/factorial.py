# Factorial Function Implementation
def factorial(n):
    # Base case:
    if n == 0 or n == 1:
        return 1
    else:
        return n * factorial(n-1)