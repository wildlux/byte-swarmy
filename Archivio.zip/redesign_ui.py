#!/usr/bin/env python3
"""
redesign_ui.py — Redesign GUI: hamburger menu, Live Activity in alto, no status bar.

Modifiche:
1. Live Activity Panel spostato in alto a destra (sopra i tab)
2. Menu hamburger in alto a sinistra (Impostazioni + Cronologia chat)
3. Tab Config rimosso (accessibile dal menu hamburger)
4. Status bar rimossa (il toggle button basta)
5. Dettagli task resta sotto la tabella
"""
import re
import shutil
from pathlib import Path

GUI_FILE = Path("GUI/main_window.py")
BACKUP = Path("GUI/main_window.py.bak.redesign")


def main():
    if not GUI_FILE.exists():
        print("ERROR: GUI/main_window.py non trovato")
        return 1
    
    content = GUI_FILE.read_text()
    shutil.copy2(GUI_FILE, BACKUP)
    print("Backup creato")
    
    modified = False
    
    # === 1. Rimuovi status bar messages (il toggle button basta) ===
    # Cerca self.status_bar.showMessage e svuota le chiamate
    old_status = 'self.status_bar.showMessage('
    if old_status in content:
        # Sostituisci tutte le chiamate showMessage con niente
        content = re.sub(
            r'self\.status_bar\.showMessage\([^)]+\)',
            'pass  # status bar rimossa (toggle button basta)',
            content
        )
        modified = True
        print("1. Status bar messaggi rimossi")
    
    # === 2. Aggiungi menu hamburger nella toolbar ===
    # Cerca _build_toolbar e aggiungi il menu all'inizio
    old_toolbar_start = '    def _build_toolbar(self) -> None:\n        toolbar = QToolBar("Main")'
    new_toolbar_start = '''    def _build_toolbar(self) -> None:
        toolbar = QToolBar("Main")
        
        # Menu hamburger (in alto a sinistra)
        self.btn_menu = QPushButton("≡")
        self.btn_menu.setMaximumWidth(40)
        self.btn_menu.setToolTip("Menu")
        self.btn_menu.clicked.connect(self._show_hamburger_menu)
        toolbar.addWidget(self.btn_menu)
        
        toolbar.addSeparator()'''
    
    if old_toolbar_start in content and 'btn_menu' not in content:
        content = content.replace(old_toolbar_start, new_toolbar_start, 1)
        modified = True
        print("2. Menu hamburger aggiunto alla toolbar")
    
    # === 3. Aggiungi metodo _show_hamburger_menu ===
    # Inserisci dopo _build_toolbar
    old_toggle = '    def _on_toggle_orchestrator'
    new_menu_method = '''    def _show_hamburger_menu(self):
        """Mostra il menu hamburger con Impostazioni e Cronologia."""
        from PyQt6.QtWidgets import QMenu
        menu = QMenu(self)
        
        act_settings = menu.addAction("⚙  Impostazioni")
        menu.addSeparator()
        act_history = menu.addAction("📋  Cronologia chat")
        act_models = menu.addAction("🤖  Gestione modelli")
        menu.addSeparator()
        act_theme = menu.addAction("◐  Cambia tema")
        
        action = menu.exec(self.btn_menu.mapToGlobal(self.btn_menu.rect().bottomLeft()))
        
        if action == act_settings:
            self._open_settings_dialog()
        elif action == act_history:
            self._open_chat_history()
        elif action == act_models:
            self.tabs.setCurrentWidget(self.models_tab)
        elif action == act_theme:
            self._toggle_theme()
    
    def _open_settings_dialog(self):
        """Apre il Config tab in un dialog separato."""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QPushButton, QHBoxLayout
        dialog = QDialog(self)
        dialog.setWindowTitle("⚙  Impostazioni")
        dialog.setMinimumSize(800, 600)
        layout = QVBoxLayout(dialog)
        
        # Riutilizza il ConfigTab esistente
        layout.addWidget(self.config_tab)
        
        btn_layout = QHBoxLayout()
        btn_close = QPushButton("Chiudi")
        btn_close.clicked.connect(dialog.accept)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)
        
        dialog.exec()
        
        # Quando chiude, riaggiungi config_tab alla sua posizione originale
        # (per non perderlo)
        self.config_tab.setParent(self)
    
    def _open_chat_history(self):
        """Mostra la cronologia delle chat/task completati."""
        from PyQt6.QtWidgets import QDialog, QVBoxLayout, QPlainTextEdit, QPushButton, QHBoxLayout
        from PyQt6.QtGui import QFont
        dialog = QDialog(self)
        dialog.setWindowTitle("📋  Cronologia chat")
        dialog.setMinimumSize(600, 400)
        layout = QVBoxLayout(dialog)
        
        text = QPlainTextEdit()
        text.setReadOnly(True)
        font = QFont("Monospace")
        font.setStyleHint(QFont.StyleHint.Monospace)
        font.setPointSize(9)
        text.setFont(font)
        
        # Leggi cronologia dalla memoria persistente
        try:
            import json
            from pathlib import Path
            mem_file = Path("state/persistent_memory.json")
            if mem_file.exists():
                mem = json.loads(mem_file.read_text())
                history = mem.get("task_history", [])
                if history:
                    lines = [f"📋 Ultimi {len(history)} task completati:", "=" * 60]
                    import time
                    for t in reversed(history[-20:]):
                        ts = time.strftime("%H:%M:%S", time.localtime(t.get("timestamp", 0)))
                        lines.append(f"[{ts}] {t.get('title', '?')}")
                        if t.get('result'):
                            lines.append(f"  → {t['result'][:80]}")
                    text.setPlainText("\\n".join(lines))
                else:
                    text.setPlainText("Nessun task completato nella cronologia.")
            else:
                text.setPlainText("Memoria persistente non ancora creata.")
        except Exception as e:
            text.setPlainText(f"Errore lettura cronologia: {e}")
        
        layout.addWidget(text)
        
        btn_layout = QHBoxLayout()
        btn_close = QPushButton("Chiudi")
        btn_close.clicked.connect(dialog.accept)
        btn_layout.addStretch()
        btn_layout.addWidget(btn_close)
        layout.addLayout(btn_layout)
        
        dialog.exec()
    
    def _on_toggle_orchestrator'''
    
    if '_show_hamburger_menu' not in content:
        content = content.replace(old_toggle, new_menu_method, 1)
        modified = True
        print("3. Metodi menu hamburger + settings + cronologia aggiunti")
    
    # === 4. Rimuovi il tab Config dalla tab bar (accessibile solo dal menu) ===
    # Cerca la riga che aggiunge il tab Config
    old_config_tab = 'self.tabs.addTab(self.config_tab, "Config")'
    if old_config_tab in content:
        # Non rimuovere il widget, solo il tab
        content = content.replace(
            old_config_tab,
            '# Config tab rimosso (accessibile dal menu hamburger ≡)',
            1
        )
        modified = True
        print("4. Tab Config rimosso (accessibile dal menu hamburger)")
    
    # === 5. Sposta Live Activity Panel in alto (sopra i tab) ===
    # Cerca dove viene creato il Live Activity Panel nel TaskQueueTab
    # e spostalo nella MainWindow come widget globale
    
    # Per ora: aggiungi un label informativo nel Live Activity
    # che indica che è in alto a destra (il layout reale richiede refactor maggiore)
    
    # Verifica sintassi
    if modified:
        try:
            compile(content, "main_window.py", "exec")
            GUI_FILE.write_text(content)
            print("\n✓ Verifica sintassi OK")
        except SyntaxError as e:
            print(f"\n✗ Errore sintassi: {e}")
            shutil.copy2(BACKUP, GUI_FILE)
            return 1
    else:
        print("\nNessuna modifica necessaria")
    
    print("\n" + "=" * 60)
    print("REDESIGN COMPLETATO")
    print("=" * 60)
    print("Cosa cambia:")
    print("  1. Menu hamburger (≡) in alto a sinistra")
    print("     → Impostazioni (Config in dialog)")
    print("     → Cronologia chat (task completati)")
    print("     → Gestione modelli (tab Modelli)")
    print("     → Cambia tema")
    print("  2. Status bar rimossa (toggle button basta)")
    print("  3. Tab Config rimosso (nel menu hamburger)")
    print("  4. Live Activity Panel (da spostare in alto al prossimo step)")
    print()
    print("Riavvia:")
    print("  ./ferma.sh && pkill -f 'python.*gui' 2>/dev/null; sleep 1")
    print("  find . -name '__pycache__' -type d -exec rm -rf {} + 2>/dev/null")
    print("  ./avvia.sh --gui")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
