#!/usr/bin/env python3
"""BYTE-SWARMY Control Center - interfaccia ridisegnata (PyQt6).

Avvio:
    pip install PyQt6
    python3 control_center.py [percorso/config.toml]

Il backend qui e' un SIMULATORE (classe MockBackend) per provare l'interfaccia.
Per collegare l'orchestratore vero basta sostituirlo con un oggetto che espone
gli stessi segnali e metodi (vedi MockBackend).
"""
import copy
import json
import random
import re
import shutil
import sys
import time
import tomllib
from collections import deque
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from PyQt6.QtCore import QEvent, QLocale, QObject, QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QKeySequence, QPainter, QPen, QPolygonF, QShortcut
from PyQt6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QDialog, QDoubleSpinBox,
    QFileDialog, QFormLayout, QFrame, QGridLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMainWindow, QMenu, QPlainTextEdit, QPushButton, QScrollArea, QSlider,
    QSpinBox, QSplitter, QTabWidget, QTreeWidget, QTreeWidgetItem,
    QVBoxLayout, QWidget,
)

from theme.theme import apply_theme, set_prop, toggle_theme

# ----------------------------------------------------------------------------
# Configurazione (TOML)
# ----------------------------------------------------------------------------
DEFAULT_CFG = {
    "ollama": {"host": "http://localhost:11434", "request_timeout": 120},
    "models": {
        "orchestrator": {
            "name": "qwen2.5:0.5b", "temperature": 0.1, "top_p": 0.8, "top_k": 20,
            "repeat_penalty": 1.15, "repeat_last_n": 256, "num_ctx": 2048, "num_predict": 256,
        }
    },
    "timestral": {"temp_cold": 50.0, "temp_warm": 65.0, "temp_hot": 80.0},
}

# (gruppo, etichetta, percorso, tipo, (min, max, passo), richiede riavvio)
# Adatta i percorsi ai nomi reali delle chiavi del tuo config.toml.
M = ("models", "orchestrator")
FIELDS = [
    ("Ollama", "Host", ("ollama", "host"), "text", None, True),
    ("Ollama", "Timeout richieste (s)", ("ollama", "request_timeout"), "int", (1, 3600, 1), False),
    ("Modello: orchestrator", "Nome", M + ("name",), "text", None, True),
    ("Modello: orchestrator", "Temperature", M + ("temperature",), "slider", (0.0, 1.5, 0.05), False),
    ("Modello: orchestrator", "Top P", M + ("top_p",), "slider", (0.0, 1.0, 0.05), False),
    ("Modello: orchestrator", "Top K", M + ("top_k",), "int", (1, 200, 1), False),
    ("Modello: orchestrator", "Repeat penalty", M + ("repeat_penalty",), "float", (0.5, 2.0, 0.05), False),
    ("Modello: orchestrator", "Repeat last N", M + ("repeat_last_n",), "int", (0, 4096, 16), False),
    ("Modello: orchestrator", "Context", M + ("num_ctx",), "int", (256, 131072, 256), True),
    ("Modello: orchestrator", "Predict", M + ("num_predict",), "int", (16, 8192, 16), False),
    ("Timestral (soglie, °C)", "Freddo (ottimizza)", ("timestral", "temp_cold"), "float", (20, 110, 1), False),
    ("Timestral (soglie, °C)", "Caldo (rallenta x1.7)", ("timestral", "temp_warm"), "float", (20, 110, 1), False),
    ("Timestral (soglie, °C)", "Critico (rallenta x2.5)", ("timestral", "temp_hot"), "float", (20, 110, 1), False),
]
RESTART_PATHS = {f[2] for f in FIELDS if f[5]}

PRESETS = {
    "Low power": {M + ("temperature",): 0.1, M + ("num_ctx",): 1024, M + ("num_predict",): 128},
    "Bilanciato": {M + ("temperature",): 0.1, M + ("num_ctx",): 2048, M + ("num_predict",): 256},
    "Max qualità": {M + ("temperature",): 0.3, M + ("num_ctx",): 4096, M + ("num_predict",): 512},
}


def get_in(d, path):
    for k in path:
        d = d[k]
    return d


def set_in(d, path, value):
    for k in path[:-1]:
        d = d.setdefault(k, {})
    d[path[-1]] = value


def deep_merge(base, extra):
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            deep_merge(base[k], v)
        else:
            base[k] = v
    return base


def _key(k):
    return k if re.fullmatch(r"[A-Za-z0-9_-]+", k) else json.dumps(k)


def _fmt(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return repr(round(v, 4))
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, list) and not any(isinstance(x, (dict, list)) for x in v):
        return "[" + ", ".join(_fmt(x) for x in v) + "]"
    raise TypeError(f"tipo TOML non supportato dal writer: {type(v).__name__}")


def dump_toml(d, prefix=""):
    scalars = {k: v for k, v in d.items() if not isinstance(v, dict)}
    tables = {k: v for k, v in d.items() if isinstance(v, dict)}
    out = []
    if prefix and (scalars or not tables):
        out.append(f"[{prefix}]")
    out += [f"{_key(k)} = {_fmt(v)}" for k, v in scalars.items()]
    if scalars or prefix:
        out.append("")
    for k, v in tables.items():
        out.append(dump_toml(v, f"{prefix}.{_key(k)}" if prefix else _key(k)))
    return "\n".join(out)


# ----------------------------------------------------------------------------
# Backend simulato
# ----------------------------------------------------------------------------
@dataclass
class Task:
    id: str
    title: str
    kind: str = "code"
    state: str = "pending"
    attempts: int = 0
    source: str = "manual"
    parent: str | None = None
    output: str = ""
    progress: int = 0


class MockBackend(QObject):
    """Interfaccia attesa dalla GUI. Sostituiscila con il tuo orchestratore."""
    changed = pyqtSignal()          # la coda task e' cambiata
    log = pyqtSignal(str)           # riga di log
    metrics = pyqtSignal(dict)      # temp, load, freq, mem, gpu, tok_s, ttft, kv, model, active
    run_state = pyqtSignal(str)     # "stopped" | "running" | "paused"

    def __init__(self):
        super().__init__()
        self.tasks: dict[str, Task] = {}
        self.running = False
        self.paused = False
        self.hot = 80.0
        self.temp = 52.0
        self.mcp: list[dict] = []
        self._n = 0
        self._seed()
        self._t1 = QTimer(self, interval=1000, timeout=self.tick)
        self._t2 = QTimer(self, interval=2000, timeout=self.sample)
        self._t1.start()
        self._t2.start()

    def _seed(self):
        a = self._new("Scrivi hello world in C", "code", "done")
        self._new("Creare file sorgente hello_world.c", "implement", "done", a, attempts=2)
        self._new("Compilare ed eseguire l'applicazione", "execute", "done", a)
        b = self._new("Ottimizzare il parser dei log", "code", "pending")
        self._new("Analizzare il formato attuale", "analyze", "failed", b, attempts=1)
        self._new("Riscrivere la funzione di parsing", "implement", "pending", b)
        self._refresh_parents()

    def _new(self, title, kind, state="pending", parent=None, attempts=0):
        if parent is None:
            self._n += 1
            tid = str(self._n)
        else:
            tid = f"{parent}.{sum(1 for t in self.tasks.values() if t.parent == parent) + 1}"
        self.tasks[tid] = Task(tid, title, kind, state, attempts, parent=parent)
        return tid

    def children(self, tid):
        return [t for t in self.tasks.values() if t.parent == tid]

    def add_task(self, text):
        p = self._new(text[:60], "code")
        self._new("Creare file sorgente", "implement", parent=p)
        self._new("Compilare ed eseguire", "execute", parent=p)
        self.log.emit(f"[queue] aggiunto task #{p}: {text[:60]}")
        self.changed.emit()
        return p

    def rerun(self, ids):
        for i in ids:
            if i in self.tasks:
                t = self.tasks[i]
                t.state, t.progress, t.attempts = "pending", 0, t.attempts + 1
                for c in self.children(i):
                    c.state, c.progress = "pending", 0
        self._refresh_parents()
        self.changed.emit()

    def reset(self, ids):
        for i in ids:
            if i in self.tasks:
                self.tasks[i].state = "pending"
                self.tasks[i].progress = 0
        self._refresh_parents()
        self.changed.emit()

    def delete(self, ids):
        doomed = set(ids)
        doomed |= {t.id for t in self.tasks.values() if t.parent in doomed}
        for i in doomed:
            self.tasks.pop(i, None)
        self.changed.emit()

    def clear_done(self):
        self.delete([t.id for t in self.tasks.values() if t.state == "done" and t.parent is None])

    def start(self):
        self.running = True
        self.log.emit("[orchestrator] avviato")
        self.run_state.emit("running")

    def stop(self):
        self.running = False
        self.paused = False
        self.log.emit("[orchestrator] fermato")
        self.run_state.emit("stopped")

    def set_thresholds(self, hot):
        self.hot = hot

    def _refresh_parents(self):
        for t in self.tasks.values():
            kids = self.children(t.id)
            if not kids:
                continue
            states = {k.state for k in kids}
            t.state = ("done" if states == {"done"} else "failed" if "failed" in states
                       else "running" if "running" in states else "pending")

    def tick(self):
        if not self.running or self.paused:
            return
        changed = False
        for t in self.tasks.values():
            if t.state == "running":
                t.progress += 1
                if t.progress >= 2:
                    ok = random.random() > 0.15
                    t.state = "done" if ok else "failed"
                    t.output = f"Task #{t.id} {'completato' if ok else 'fallito'} alle {datetime.now():%H:%M:%S}"
                    self.log.emit(f"[task] #{t.id} {t.state}")
                changed = True
        if not any(t.state == "running" for t in self.tasks.values()):
            todo = [t for t in self.tasks.values() if t.state == "pending" and not self.children(t.id)]
            if todo:
                todo[0].state, todo[0].progress = "running", 0
                self.log.emit(f"[task] #{todo[0].id} in esecuzione")
                changed = True
        if changed:
            self._refresh_parents()
            self.changed.emit()

    def sample(self):
        self.temp = min(95, max(42, self.temp + random.uniform(-3, 3.2)))
        was = self.paused
        self.paused = self.running and self.temp >= self.hot
        if self.paused != was:
            self.run_state.emit("paused" if self.paused else "running")
        active = next((t for t in self.tasks.values() if t.state == "running"), None)
        self.metrics.emit({
            "temp": self.temp, "gpu": 41 + (self.temp - 50) * 0.3, "load": random.randint(3, 30),
            "freq": random.choice([887, 900, 3053, 3165]), "mem": random.randint(48, 55),
            "tok_s": 14.9, "ttft": 413, "kv": 62.8, "model": "phi3:mini",
            "active": f"#{active.id} {active.title}" if active else "",
        })

    def add_mcp(self, url):
        name = re.sub(r"^https?://", "", url).split("/")[0].split(":")[0] or "server"
        row = {"name": name, "url": url, "poll": 10, "state": "connesso", "tools": random.randint(1, 6)}
        self.mcp.append(row)
        self.log.emit(f"[mcp] aggiunto {name}, tool scoperti: {row['tools']}")
        return row


# ----------------------------------------------------------------------------
# Widget di supporto
# ----------------------------------------------------------------------------
def make_label(text="", **props):
    lab = QLabel(text)
    for k, v in props.items():
        lab.setProperty(k, v)
    return lab


class MetricCard(QFrame):
    def __init__(self, title, unit):
        super().__init__()
        self.setObjectName("card")
        self.unit = unit
        lay = QVBoxLayout(self)
        lay.addWidget(make_label(title, role="muted"))
        self.value = make_label("-", role="metric")
        lay.addWidget(self.value)

    def set(self, v, fmt="{:.0f}"):
        self.value.setText(f"{fmt.format(v)} {self.unit}")


class SparkChart(QWidget):
    """Andamento temperatura con le fasce delle soglie."""

    def __init__(self):
        super().__init__()
        self.setMinimumHeight(110)
        self.data, self.thr = [], (50.0, 65.0, 80.0)

    def set_data(self, data, thr):
        self.data, self.thr = list(data), thr
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(34, 8, -10, -8)
        lo, hi = 30.0, 100.0
        cold, warm, hot = self.thr

        def y(t):
            return r.bottom() - (min(max(t, lo), hi) - lo) / (hi - lo) * r.height()

        p.fillRect(QRectF(r.left(), y(warm), r.width(), y(cold) - y(warm)), QColor(60, 170, 110, 35))
        p.fillRect(QRectF(r.left(), y(hot), r.width(), y(warm) - y(hot)), QColor(240, 170, 40, 45))
        p.fillRect(QRectF(r.left(), r.top(), r.width(), y(hot) - r.top()), QColor(220, 70, 60, 45))
        p.setPen(QPen(QColor(128, 136, 150), 1, Qt.PenStyle.DashLine))
        for t in (cold, warm, hot):
            p.drawLine(QPointF(r.left(), y(t)), QPointF(r.right(), y(t)))
            p.drawText(QPointF(4, y(t) + 4), f"{t:.0f}°")
        n = len(self.data)
        if n > 1:
            pts = [QPointF(r.left() + i * r.width() / (n - 1), y(v)) for i, v in enumerate(self.data)]
            p.setPen(QPen(QColor("#5b92ff"), 2))
            p.drawPolyline(QPolygonF(pts))


class CommandPalette(QDialog):
    def __init__(self, parent, commands):
        super().__init__(parent)
        self.setWindowTitle("Comandi")
        self.resize(460, 340)
        self.commands = commands
        lay = QVBoxLayout(self)
        self.edit = QLineEdit()
        self.edit.setPlaceholderText("Cerca un comando")
        self.list = QListWidget()
        lay.addWidget(self.edit)
        lay.addWidget(self.list)
        self.edit.textChanged.connect(self.filter)
        self.edit.returnPressed.connect(self.run_current)
        self.list.itemActivated.connect(lambda _i: self.run_current())
        self.edit.installEventFilter(self)
        self.filter("")

    def filter(self, text):
        self.list.clear()
        for label, keys, fn in self.commands:
            if text.lower() in label.lower():
                it = QListWidgetItem(f"{label}        {keys}".rstrip())
                it.setData(Qt.ItemDataRole.UserRole, fn)
                self.list.addItem(it)
        self.list.setCurrentRow(0)

    def eventFilter(self, obj, ev):
        if obj is self.edit and ev.type() == QEvent.Type.KeyPress and ev.key() in (Qt.Key.Key_Down, Qt.Key.Key_Up):
            step = 1 if ev.key() == Qt.Key.Key_Down else -1
            self.list.setCurrentRow(max(0, min(self.list.count() - 1, self.list.currentRow() + step)))
            return True
        return super().eventFilter(obj, ev)

    def run_current(self):
        it = self.list.currentItem()
        if it:
            fn = it.data(Qt.ItemDataRole.UserRole)
            self.accept()
            QTimer.singleShot(0, fn)


# ----------------------------------------------------------------------------
# Finestra principale
# ----------------------------------------------------------------------------
STATE_TEXT = {"done": "✓ done", "failed": "✗ failed", "pending": "… pending", "running": "▶ running"}


class ControlCenter(QMainWindow):
    def __init__(self, config_path: Path):
        super().__init__()
        self.setWindowTitle("BYTE-SWARMY · Control Center")
        self.config_path = config_path
        self.backend = MockBackend()
        self.history = deque((random.uniform(48, 62) for _ in range(60)), maxlen=720)
        self.cfg = self._load_config()
        self._syncing = False
        self.restart_pending = False
        self._backed_up = False
        self.save_timer = QTimer(self, singleShot=True, interval=800, timeout=self.save_config)

        root = QWidget()
        self.setCentralWidget(root)
        v = QVBoxLayout(root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        v.addWidget(self._build_topbar())

        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_tasks_tab(), "Task")
        self.tabs.addTab(self._build_mcp_tab(), "Fonti")
        self.tabs.addTab(self._build_settings_tab(), "Impostazioni")
        self.bottom = QTabWidget()
        self.bottom.addTab(self._build_logs_tab(), "Logs")
        self.bottom.addTab(self._build_thermal_tab(), "Timestral")
        self.bottom.hide()
        self.vsplit = QSplitter(Qt.Orientation.Vertical)
        self.vsplit.addWidget(self.tabs)
        self.vsplit.addWidget(self.bottom)
        self.vsplit.setChildrenCollapsible(False)
        v.addWidget(self.vsplit, 1)

        self.state_lbl = make_label("● Orchestratore fermo", role="muted")
        self.statusBar().addWidget(self.state_lbl)
        self.statusBar().addPermanentWidget(make_label("Ctrl+K comandi", role="hint"))

        self._wire()
        self._setup_shortcuts()
        self.refresh_tasks()
        self.apply_cfg_side_effects()
        self.backend.sample()

    # --- costruzione UI ---------------------------------------------------
    def _build_topbar(self):
        bar = QWidget()
        h = QHBoxLayout(bar)
        h.setContentsMargins(14, 10, 14, 10)
        self.btn_run = QPushButton("▶ Avvia")
        self.btn_run.setProperty("role", "start")
        self.btn_run.setToolTip("Avvia o ferma l'orchestratore (Ctrl+R)")
        self.lbl_temps = make_label("CPU - · GPU -")
        self.lbl_model = make_label("", role="muted")
        self.pill = make_label("NORMAL", thermal="normal")
        self.pill.setToolTip("Stato termico (Timestral). Ctrl+T per i dettagli")
        h.addWidget(self.btn_run)
        h.addSpacing(10)
        h.addWidget(self.lbl_temps)
        h.addSpacing(10)
        h.addWidget(self.lbl_model)
        h.addStretch(1)
        h.addWidget(self.pill)
        return bar

    def _build_tasks_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(14, 12, 14, 10)
        self.quick = QLineEdit()
        self.quick.setObjectName("quickCommand")
        self.quick.setPlaceholderText("Scrivi in qualsiasi lingua: 'crea funzione X', 'optimize Y'… e premi Invio")
        v.addWidget(self.quick)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(["Task", "Stato", "Prove", ""])
        self.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tree.setIndentation(22)
        self.tree.setUniformRowHeights(True)
        hd = self.tree.header()
        hd.setStretchLastSection(False)
        hd.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for c in (1, 2, 3):
            hd.setSectionResizeMode(c, QHeaderView.ResizeMode.ResizeToContents)

        self.details = QPlainTextEdit()
        self.details.setObjectName("logView")
        self.details.setReadOnly(True)
        self.details.setPlaceholderText("Seleziona un task per vedere i dettagli")
        self.hsplit = QSplitter(Qt.Orientation.Horizontal)
        self.hsplit.addWidget(self.tree)
        self.hsplit.addWidget(self.details)
        self.hsplit.setStretchFactor(0, 3)
        self.hsplit.setStretchFactor(1, 2)
        self.details.hide()
        v.addWidget(self.hsplit, 1)

        live = QFrame()
        live.setObjectName("card")
        lh = QHBoxLayout(live)
        self.live_state = make_label("In attesa")
        self.live_metrics = make_label("", role="muted")
        lh.addWidget(self.live_state)
        lh.addStretch(1)
        lh.addWidget(self.live_metrics)
        v.addWidget(live)
        return w

    def _build_mcp_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(14, 12, 14, 10)
        self.mcp_edit = QLineEdit()
        self.mcp_edit.setObjectName("quickCommand")
        self.mcp_edit.setPlaceholderText("Incolla l'URL SSE (es. http://host:porta/sse) e premi Invio")
        v.addWidget(self.mcp_edit)
        self.mcp_tree = QTreeWidget()
        self.mcp_tree.setHeaderLabels(["Nome", "URL", "Poll (s)", "Stato", "Tool"])
        self.mcp_tree.setRootIsDecorated(False)
        self.mcp_tree.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.mcp_tree.header().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        v.addWidget(self.mcp_tree, 1)
        v.addWidget(make_label(
            "Il client si connette al server, chiama get_pending_tasks a intervalli regolari e "
            "aggiunge i task ricevuti alla coda con source=mcp:<nome>. Doppio click su una riga per modificare l'URL.",
            role="hint"))
        self.mcp_tree.parent()
        return w

    def _build_logs_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(10, 8, 10, 8)
        bar = QHBoxLayout()
        b1, b2 = QPushButton("Pulisci"), QPushButton("Esporta…")
        self.autoscroll = QCheckBox("Auto-scroll")
        self.autoscroll.setChecked(True)
        bar.addWidget(b1)
        bar.addWidget(b2)
        bar.addStretch(1)
        bar.addWidget(self.autoscroll)
        self.log_view = QPlainTextEdit()
        self.log_view.setObjectName("logView")
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(5000)
        v.addLayout(bar)
        v.addWidget(self.log_view)
        b1.clicked.connect(self.log_view.clear)
        b2.clicked.connect(self.export_logs)
        return w

    def _build_thermal_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(10, 8, 10, 8)
        grid = QGridLayout()
        self.card_temp = MetricCard("Temperatura", "°C")
        self.card_load = MetricCard("CPU load", "%")
        self.card_freq = MetricCard("CPU freq", "MHz")
        self.card_mem = MetricCard("RAM usata", "%")
        for i, c in enumerate((self.card_temp, self.card_load, self.card_freq, self.card_mem)):
            grid.addWidget(c, 0, i)
        v.addLayout(grid)
        self.advice_lbl = make_label("", role="hint")
        v.addWidget(self.advice_lbl)
        self.chart = SparkChart()
        v.addWidget(self.chart, 1)
        return w

    def _build_settings_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(14, 12, 14, 10)
        top = QHBoxLayout()
        top.addWidget(make_label("Preset", role="muted"))
        for name in PRESETS:
            b = QPushButton(name)
            b.clicked.connect(lambda _c=False, n=name: self.apply_preset(n))
            top.addWidget(b)
        top.addStretch(1)
        self.adv = QCheckBox("Modalità avanzata (TOML)")
        top.addWidget(self.adv)
        v.addLayout(top)
        self.cfg_banner = make_label("Le modifiche vengono salvate in automatico.", banner="info")
        v.addWidget(self.cfg_banner)

        self.setters = {}
        form_host = QWidget()
        outer = QVBoxLayout(form_host)
        forms = {}
        for group, label, path, kind, rng, restart in FIELDS:
            if group not in forms:
                gb = QGroupBox(group)
                forms[group] = QFormLayout(gb)
                outer.addWidget(gb)
            forms[group].addRow(label + ("  ↻" if restart else ""), self._make_editor(path, kind, rng))
        outer.addStretch(1)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(form_host)

        self.toml_edit = QPlainTextEdit()
        self.toml_edit.setObjectName("tomlView")
        self.toml_edit.hide()
        split = QSplitter(Qt.Orientation.Horizontal)
        split.addWidget(scroll)
        split.addWidget(self.toml_edit)
        v.addWidget(split, 1)
        v.addWidget(make_label("↻ = richiede il riavvio dell'orchestratore", role="hint"))
        self.sync_form_from_cfg()
        return w

    def _make_editor(self, path, kind, rng):
        if kind == "text":
            e = QLineEdit()
            e.textEdited.connect(lambda t, p=path: self._edited(p, t))
            self.setters[path] = lambda val, e=e: self._silent(e, lambda: e.setText(str(val)))
            return e
        us = QLocale(QLocale.Language.English, QLocale.Country.UnitedStates)
        if kind == "int":
            s = QSpinBox()
            s.setRange(int(rng[0]), int(rng[1]))
            s.setSingleStep(int(rng[2]))
            s.valueChanged.connect(lambda val, p=path: self._edited(p, int(val)))
            self.setters[path] = lambda val, s=s: self._silent(s, lambda: s.setValue(int(val)))
            return s
        s = QDoubleSpinBox()
        s.setLocale(us)
        s.setDecimals(2)
        s.setRange(rng[0], rng[1])
        s.setSingleStep(rng[2])
        s.valueChanged.connect(lambda val, p=path: self._edited(p, round(float(val), 3)))
        if kind == "float":
            self.setters[path] = lambda val, s=s: self._silent(s, lambda: s.setValue(float(val)))
            return s
        sl = QSlider(Qt.Orientation.Horizontal)
        sl.setRange(0, 1000)

        def to_sl(val):
            return int(round((val - rng[0]) / (rng[1] - rng[0]) * 1000))

        sl.valueChanged.connect(lambda x: s.setValue(rng[0] + x / 1000 * (rng[1] - rng[0])))
        s.valueChanged.connect(lambda val: self._silent(sl, lambda: sl.setValue(to_sl(val))))
        box = QWidget()
        hb = QHBoxLayout(box)
        hb.setContentsMargins(0, 0, 0, 0)
        hb.addWidget(sl, 1)
        hb.addWidget(s)
        self.setters[path] = lambda val, s=s: s.setValue(float(val))
        return box

    @staticmethod
    def _silent(widget, fn):
        widget.blockSignals(True)
        fn()
        widget.blockSignals(False)

    # --- segnali e scorciatoie -------------------------------------------
    def _wire(self):
        b = self.backend
        b.changed.connect(self.refresh_tasks)
        b.log.connect(self.append_log)
        b.metrics.connect(self.on_metrics)
        b.run_state.connect(self.on_run_state)
        self.btn_run.clicked.connect(self.toggle_run)
        self.quick.returnPressed.connect(self.add_quick)
        self.tree.itemSelectionChanged.connect(self.on_selection)
        self.tree.customContextMenuRequested.connect(self.task_menu)
        self.mcp_edit.returnPressed.connect(self.add_mcp)
        self.mcp_tree.itemDoubleClicked.connect(lambda it, _c: self.edit_mcp(it))
        self.mcp_tree.customContextMenuRequested.connect(self.mcp_menu)
        self.adv.toggled.connect(self.toml_edit.setVisible)
        self.toml_edit.textChanged.connect(self.on_toml_edited)

    def _setup_shortcuts(self):
        def sc(keys, fn, widget=None, local=False):
            s = QShortcut(QKeySequence(keys), widget or self)
            if local:
                s.setContext(Qt.ShortcutContext.WidgetShortcut)
            s.activated.connect(fn)

        sc("Ctrl+R", self.toggle_run)
        sc("Ctrl+K", self.open_palette)
        sc("Ctrl+1", lambda: self.tabs.setCurrentIndex(0))
        sc("Ctrl+2", lambda: self.tabs.setCurrentIndex(1))
        sc("Ctrl+3", lambda: self.tabs.setCurrentIndex(2))
        sc("Ctrl+L", lambda: self.toggle_bottom(0))
        sc("Ctrl+T", lambda: self.toggle_bottom(1))
        sc("Ctrl+Shift+T", lambda: toggle_theme(QApplication.instance()))
        sc("Del", self.delete_selected, self.tree, local=True)
        sc("Ctrl+Return", self.add_and_run, self.quick, local=True)
        self.commands = [
            ("Avvia / ferma orchestratore", "Ctrl+R", self.toggle_run),
            ("Vai a Task", "Ctrl+1", lambda: self.tabs.setCurrentIndex(0)),
            ("Vai a Fonti (MCP)", "Ctrl+2", lambda: self.tabs.setCurrentIndex(1)),
            ("Vai a Impostazioni", "Ctrl+3", lambda: self.tabs.setCurrentIndex(2)),
            ("Mostra / nascondi Logs", "Ctrl+L", lambda: self.toggle_bottom(0)),
            ("Mostra / nascondi Timestral", "Ctrl+T", lambda: self.toggle_bottom(1)),
            ("Cambia tema chiaro / scuro", "Ctrl+Shift+T", lambda: toggle_theme(QApplication.instance())),
            ("Pulisci task completati", "", self.backend.clear_done),
            ("Preset: Low power", "", lambda: self.apply_preset("Low power")),
            ("Preset: Bilanciato", "", lambda: self.apply_preset("Bilanciato")),
            ("Preset: Max qualità", "", lambda: self.apply_preset("Max qualità")),
        ]

    def open_palette(self):
        dlg = CommandPalette(self, self.commands)
        dlg.exec()

    def toggle_bottom(self, index):
        if self.bottom.isVisible() and self.bottom.currentIndex() == index:
            self.bottom.hide()
            return
        self.bottom.setCurrentIndex(index)
        self.bottom.show()
        h = self.vsplit.height()
        self.vsplit.setSizes([int(h * 0.62), int(h * 0.38)])

    # --- task ---------------------------------------------------------------
    def selected_ids(self):
        return [it.data(0, Qt.ItemDataRole.UserRole) for it in self.tree.selectedItems()]

    def refresh_tasks(self):
        sel = set(self.selected_ids())
        self.tree.blockSignals(True)
        self.tree.clear()
        items = {}
        for t in self.backend.tasks.values():
            parent = items.get(t.parent)
            it = QTreeWidgetItem(parent) if parent else QTreeWidgetItem(self.tree)
            items[t.id] = it
            it.setText(0, f"#{t.id}   {t.title}")
            it.setToolTip(0, f"{t.kind} · fonte: {t.source}")
            it.setData(0, Qt.ItemDataRole.UserRole, t.id)
            it.setText(2, str(t.attempts) if t.attempts else "")
            it.setTextAlignment(2, Qt.AlignmentFlag.AlignCenter)
            self.tree.setItemWidget(it, 1, make_label(STATE_TEXT[t.state], state=t.state))
            act = self._row_action(t)
            if act:
                self.tree.setItemWidget(it, 3, act)
            it.setSelected(t.id in sel)
        self.tree.expandAll()
        self.tree.blockSignals(False)
        self.on_selection()
        running = next((t for t in self.backend.tasks.values() if t.state == "running"), None)
        self.live_state.setText(f"▶ #{running.id} {running.title}" if running else "In attesa")

    def _row_action(self, t):
        spec = {"done": ("Ri-esegui", self.backend.rerun), "failed": ("Reset", self.backend.reset),
                "pending": ("Elimina", self.backend.delete)}.get(t.state)
        if not spec:
            return None
        btn = QPushButton(spec[0])
        if t.state == "pending":
            btn.setProperty("role", "danger")
        btn.clicked.connect(lambda _c=False, f=spec[1], i=t.id: f([i]))
        return btn

    def on_selection(self):
        ids = self.selected_ids()
        if not ids:
            self.details.hide()
            return
        t = self.backend.tasks.get(ids[0])
        if not t:
            return
        self.details.setPlainText(
            f"#{t.id}  {t.title}\nTipo: {t.kind}\nStato: {t.state}\nTentativi: {t.attempts}\n"
            f"Sorgente: {t.source}\n\n{t.output or '(nessun output)'}")
        self.details.show()

    def add_quick(self):
        text = self.quick.text().strip()
        if not text:
            return
        self.backend.add_task(text)
        self.quick.clear()

    def add_and_run(self):
        self.add_quick()
        if not self.backend.running:
            self.backend.start()

    def delete_selected(self):
        ids = self.selected_ids()
        if ids:
            self.backend.delete(ids)

    def task_menu(self, pos):
        ids = self.selected_ids()
        m = QMenu(self)
        if ids:
            m.addAction("Ri-esegui", lambda: self.backend.rerun(ids))
            m.addAction("Reset a pending", lambda: self.backend.reset(ids))
            m.addAction("Elimina", lambda: self.backend.delete(ids))
            m.addSeparator()
        m.addAction("Pulisci completati", self.backend.clear_done)
        m.exec(self.tree.viewport().mapToGlobal(pos))

    # --- avvio / stato ---------------------------------------------------
    def toggle_run(self):
        self.backend.stop() if self.backend.running else self.backend.start()

    def on_run_state(self, state):
        running = state != "stopped"
        self.btn_run.setText("■ Ferma" if running else "▶ Avvia")
        set_prop(self.btn_run, "role", "stop" if running else "start")
        text = {"stopped": "● Orchestratore fermo", "running": "● Orchestratore attivo",
                "paused": "● In pausa: CPU troppo calda"}[state]
        self.state_lbl.setText(text)
        if state == "stopped":
            set_prop(self.state_lbl, "thermal", "")
            set_prop(self.state_lbl, "role", "muted")
        else:
            set_prop(self.state_lbl, "role", "")
            set_prop(self.state_lbl, "thermal", "warm" if state == "paused" else "normal")

    def advice(self, temp):
        t = self.cfg["timestral"]
        return "hot" if temp >= t["temp_hot"] else "warm" if temp >= t["temp_warm"] else "normal"

    def on_metrics(self, m):
        self.history.append(m["temp"])
        self.lbl_temps.setText(f"CPU {m['temp']:.0f}°C · GPU {m['gpu']:.0f}°C")
        self.lbl_model.setText(f"{m['model']} · {m['tok_s']:.1f} tok/s · TTFT {m['ttft']} ms")
        self.live_metrics.setText(f"{m['tok_s']:.1f} tok/s · KV {m['kv']:.1f} MB")
        adv = self.advice(m["temp"])
        if self.pill.property("thermal") != adv:
            set_prop(self.pill, "thermal", adv)
        self.pill.setText(adv.upper())
        self.card_temp.set(m["temp"], "{:.1f}")
        self.card_load.set(m["load"])
        self.card_freq.set(m["freq"])
        self.card_mem.set(m["mem"])
        t = self.cfg["timestral"]
        self.advice_lbl.setText({"normal": "Funzionamento normale.",
                                 "warm": f"Sopra {t['temp_warm']:.0f}°C: dispatch rallentato.",
                                 "hot": f"Sopra {t['temp_hot']:.0f}°C: dispatch in pausa."}[adv])
        self.chart.set_data(self.history, (t["temp_cold"], t["temp_warm"], t["temp_hot"]))
        self.append_log(f"[timestral] temp={m['temp']:.1f}C load={m['load']}% freq={m['freq']}MHz mem={m['mem']}%",
                        level="DEBUG")

    def append_log(self, line, level="INFO"):
        self.log_view.appendPlainText(f"{datetime.now():%Y-%m-%d %H:%M:%S} [{level}] {line}")
        if self.autoscroll.isChecked():
            sb = self.log_view.verticalScrollBar()
            sb.setValue(sb.maximum())

    def export_logs(self):
        path, _ = QFileDialog.getSaveFileName(self, "Esporta log", "byte-swarmy.log", "Log (*.log *.txt)")
        if path:
            Path(path).write_text(self.log_view.toPlainText(), encoding="utf-8")

    # --- MCP ---------------------------------------------------------------
    def add_mcp(self):
        url = self.mcp_edit.text().strip()
        if not re.match(r"^https?://", url):
            self.cfg_banner_msg = "URL non valido"
            self.statusBar().showMessage("Inserisci un URL che inizi con http:// o https://", 4000)
            return
        row = self.backend.add_mcp(url)
        self.mcp_edit.clear()
        it = QTreeWidgetItem([row["name"], row["url"], str(row["poll"]), row["state"], str(row["tools"])])
        self.mcp_tree.addTopLevelItem(it)
        self.statusBar().showMessage(f"{row['name']}: scoperti {row['tools']} tool", 4000)

    def edit_mcp(self, it):
        url, ok = QInputDialog.getText(self, "Modifica server", "URL SSE:", text=it.text(1))
        if ok and url.strip():
            it.setText(1, url.strip())

    def mcp_menu(self, pos):
        it = self.mcp_tree.itemAt(pos)
        if not it:
            return
        m = QMenu(self)
        m.addAction("Modifica URL", lambda: self.edit_mcp(it))
        m.addAction("Scopri tool", lambda: self.statusBar().showMessage(f"Scoperta tool su {it.text(0)}…", 3000))
        m.addAction("Elimina", lambda: self.mcp_tree.takeTopLevelItem(self.mcp_tree.indexOfTopLevelItem(it)))
        m.exec(self.mcp_tree.viewport().mapToGlobal(pos))

    # --- configurazione ----------------------------------------------------
    def _load_config(self):
        cfg = copy.deepcopy(DEFAULT_CFG)
        if self.config_path.exists():
            try:
                deep_merge(cfg, tomllib.loads(self.config_path.read_text(encoding="utf-8")))
            except Exception as e:  # file esistente ma non valido: si parte dai default
                print(f"config non letto ({e}); uso i valori di default", file=sys.stderr)
        return cfg

    def sync_form_from_cfg(self):
        self._syncing = True
        for path, setter in self.setters.items():
            try:
                setter(get_in(self.cfg, path))
            except KeyError:
                pass
        self.toml_edit.setPlainText(dump_toml(self.cfg).strip() + "\n")
        self._syncing = False

    def _edited(self, path, value):
        if self._syncing:
            return
        set_in(self.cfg, path, value)
        if path in RESTART_PATHS:
            self.restart_pending = True
        self._cfg_changed()

    def _cfg_changed(self):
        self._syncing = True
        try:
            self.toml_edit.setPlainText(dump_toml(self.cfg).strip() + "\n")
        except TypeError as e:
            self._banner("error", f"Impossibile generare il TOML: {e}")
            self._syncing = False
            return
        self._syncing = False
        self.apply_cfg_side_effects()
        self._banner("info", "Modifiche non salvate, salvataggio automatico in corso…")
        self.save_timer.start()

    def on_toml_edited(self):
        if self._syncing:
            return
        try:
            parsed = tomllib.loads(self.toml_edit.toPlainText())
        except tomllib.TOMLDecodeError as e:
            self.save_timer.stop()
            self._banner("error", f"TOML non valido, nulla viene salvato: {e}")
            return
        self.cfg = deep_merge(copy.deepcopy(DEFAULT_CFG), parsed)
        self.restart_pending = True
        self._syncing = True
        for path, setter in self.setters.items():
            try:
                setter(get_in(self.cfg, path))
            except KeyError:
                pass
        self._syncing = False
        self.apply_cfg_side_effects()
        self._banner("info", "TOML valido, salvataggio automatico in corso…")
        self.save_timer.start()

    def apply_cfg_side_effects(self):
        self.backend.set_thresholds(float(self.cfg["timestral"]["temp_hot"]))

    def apply_preset(self, name):
        for path, val in PRESETS[name].items():
            set_in(self.cfg, path, val)
            if path in self.setters:
                self._syncing = True
                self.setters[path](val)
                self._syncing = False
            if path in RESTART_PATHS:
                self.restart_pending = True
        self._cfg_changed()
        self.statusBar().showMessage(f"Preset «{name}» applicato", 4000)

    def save_config(self):
        try:
            text = dump_toml(self.cfg).strip() + "\n"
            if self.config_path.exists() and not self._backed_up:
                shutil.copy2(self.config_path, self.config_path.with_suffix(".toml.bak"))
                self._backed_up = True
            self.config_path.write_text(text, encoding="utf-8")
        except Exception as e:
            self._banner("error", f"Salvataggio fallito: {e}")
            return
        extra = " Alcune modifiche (↻) richiedono il riavvio dell'orchestratore." if self.restart_pending else ""
        self._banner("ok", f"Salvato alle {time.strftime('%H:%M:%S')}.{extra}")

    def _banner(self, kind, text):
        set_prop(self.cfg_banner, "banner", kind)
        self.cfg_banner.setText(text)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("BYTE-SWARMY")
    apply_theme(app)
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).with_name("config.toml")
    win = ControlCenter(path)
    win.resize(1100, 720)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
